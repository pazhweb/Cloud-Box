<?php

namespace App\Services\Entries;

class FolderExistsException extends \Exception {
    //
}