<?php

namespace Common\Comments;

use Common\Votes\Vote;

class CommentVote extends Vote
{
}
