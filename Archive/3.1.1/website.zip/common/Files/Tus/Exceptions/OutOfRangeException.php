<?php

namespace Common\Files\Tus\Exceptions;

class OutOfRangeException extends \OutOfRangeException
{
}
